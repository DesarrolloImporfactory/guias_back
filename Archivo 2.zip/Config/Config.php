<?php


const HOST = 'localhost';
const USER = 'root';
const PASSWORD = "";
const DB = 'guias';
const CHARSET = "utf8";
